zip slip
