Overwritten via zip slip
